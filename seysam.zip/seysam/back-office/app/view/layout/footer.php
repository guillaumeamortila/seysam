<div id="footer">
	<h2>BACK OFFICE</h2>
	<p id="copyright">© · S E Y S A M · 2017</p>
	<div id="top-page"><a href="#">^</a></div>
</div>
</body>
</html>