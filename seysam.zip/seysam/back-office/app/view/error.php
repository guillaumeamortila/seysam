<?php
define('PAGE_TITLE','ERREUR 404');
include('app/view/layout/header.php');
?>

<p id="error404">ERREUR ... La page demandée n'existe pas !&nbsp;&nbsp;&nbsp;:(</p>

<?php include('app/view/layout/footer.php') ?>