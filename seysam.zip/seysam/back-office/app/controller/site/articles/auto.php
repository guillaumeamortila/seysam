<?php

define("PAGE_TITLE", "Autocomplétion");
include_once("app/view/site/articles/auto.php");