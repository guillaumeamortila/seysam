<?php

if(!defined(_BASE_URL)) die("Ressource interdite");

define("PAGE_LANG","fr");
define("PAGE_CHARSET","utf-8");

define("DEFAULT_PT","site");
define("DEFAULT_MODULE","articles");
define("DEFAULT_ACTION","index");

define("PAGINATION_ARTICLES",4);
define("PAGINATION_COMMENTS",6);
define("PAGINATION_PRODUITS",6);

define("USER_LAMBDA", 0);
define("USER_ADMIN", 1);

define("SALT", "vOTw2e4!Od?i");
