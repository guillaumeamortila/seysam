<?php
try
	{
		$dns = 'mysql:host=localhost;port=3306;dbname=gamortila_seysam';
		$utilisateur = 'gamortila';
		$motDePasse = '5uf2w4haqw';
		$pdo = new PDO( $dns, $utilisateur, $motDePasse);
	}
	catch ( Exception $e )
	{
		die("La connexion a échoué : ".$e->getMessage());
	}