<?php
if(!defined("_BASE_URL")) die("Ressource interdite!");
include("app/view/layout/header.inc.php");
?>

<br><br><br><br>
<h2> ERREUR 404 : La page que vous cherchez n'existe pas<span class="dot">.</span></h2>
<a href="index.php">›› nous vous invitons à revenir à la page d'accueil ‹‹</a>
<br><br><br><br><br>

<?php include("app/view/layout/footer.inc.php"); ?>
