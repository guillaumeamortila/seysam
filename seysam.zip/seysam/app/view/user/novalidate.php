<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

include("app/view/layout/header.inc.php"); ?>

    <div>
        Votre compte n'est pas validé
    </div>

<?php include("app/view/layout/footer.inc.php"); ?>