<div class="popup sign-up">
  <div class="close"><img src="webroot/img/icons/close.svg"></div>
  <div class="title">
    Inscription<span class="dot">.</span>
  </div>
  <div class="undertitle">Créez un compte pour faire partie de la communauté Seysam, commander vos produits préférés et recevoir notre newsletter et offres spéciales.
  </div>
  <div>
    <form action="?module=user&action=inscription" method="post">
      <input autofocus class="champ" type="text" placeholder="Adresse e-mail" id="email-inscription" name="email" required />
      <input class="champ" type="text" placeholder="Prénom" name="prenom" id="prenom-inscription" required autofocus />
      <input class="champ" type="text" placeholder="Nom" name="nom" id="nom-inscription" required autofocus />
      <input class="champ" type="password" placeholder="Mot de passe" name="password" id="password-inscription" required autofocus />
      <div class="checkbox"><input type="checkbox" name="cours" size="35 px" value="confirme" /><p>Je souhaite recevoir par e-mail des coupons, des promotions, des sondages et les actualités sur Seysam.</p></div>
      <p class="undertitle">En créant un compte, j'accepte les <a href="#">Conditions générales</a>, la <a href="#">Politique de non-discrimination</a>, les <a href="#">Conditions de service relatives aux paiements</a>, la <a href="#">Politique de confidentialité</a> et la <a href="#">Politique de remboursement</a> de Seysam.</p>
      <input id="btn" value="JE M'INSCRIS" type="submit" name="inscription" />
    </form>
  </div>
</div>

<div class="popup sign-in">
  <div class="close"><img src="webroot/img/icons/close.svg"></div>
  <div class="title">
    Connexion<span class="dot">.</span>
  </div>
  <div class="undertitle">Connectez-vous.
  </div>
  <div>
    <form action="#" method="post" id="connexion-form">
      <input autofocus class="champ" type="text" placeholder="Adresse e-mail" id="email-connexion" name="email" required />
      <input class="champ" type="password" placeholder="Mot de passe" name="password" id="password-connexion" required autofocus />
      <input id="btn" value="JE ME CONNECTE" type="submit" name="connexion" />
    </form>
  </div>
</div>

<div class="popup-bg">
</div>

<script type="text/javascript">
  $(document).ready(function(){
    $("#connexion-form").submit(function(){
        $.post("?module=user&action=loginajax", $("#connexion-form").serialize(), function(msg){

            if(msg!=0){ // login réussi
                console.log(msg);

                // var inner = '<ul class="nav-mobile"><li><a href="?module=user&action=logout" data-toggle="tooltip" data-placement="bottom" title="Modifier">Deconnexion</a></li></ul>';
                var inner = '<div class="nav-link"><a href="?module=actualite&action=index">Actualités</a></div><div class="nav-link"><a href="#">Idées cadeaux</a></div><div class="nav-link"><a href="?module=user&action=detail">Espace perso</a></div><div class="appear"><input class="searchbar" type="text" name="search" placeholder="Tapez votre recherche"></div><div class="nav-link loupe"><a href="#"><div class="search"></div></a></div><div class="nav-link"><a href="?module=panier&action=index"><div class="cart"></div></a></div><div class="notif" style="display: none"></div>';
                // $(".nav"    ).html(inner);

                $('.menu').html(inner);
            } else {
                $("#error").html("Mauvaise identification, réessayez");
            }
        });
        $(".popup").hide();
        $(".popup-bg").hide();
        return false; // ne pas recharger la page
    });
});
</script>