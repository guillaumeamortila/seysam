<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

include("app/view/layout/header.inc.php"); ?>

<div class="conf-paiement">
    <div class="rounded-nav"></div>
    <div class="card-container first">
        <div>
            <h1 class="justify-center">
	            <?php
	            	if ($_GET["notif"]=="ok")
	            		echo "Votre inscription a bien été effectuée";
	            	if ($_GET["notif"]=="nok")
	            		echo "Une erreur s'est produite lors de votre inscription";
	            ?>
	            <span class="red">.</span>
            </h1>
        </div>
        <div>
        	<?php
            	if ($_GET["notif"]=="ok")
            		echo "Un mail vous a été envoyé, Veuillez cliquer dessus pour valider votre adresse mail et ainsi pouvoir vous connecter sur notre plateforme !";
            	if ($_GET["notif"]=="nok")
            		echo "Suite à un problème survenu lors de l'enregistrement de votre profil, votre compte n'a pas pu être créé. Nous vous prions de nous excuser et nous vous invitons à réessayer à nouveau.";
            ?>
        </div>
    </div>
</div>

<?php include("app/view/layout/footer.inc.php"); ?>
