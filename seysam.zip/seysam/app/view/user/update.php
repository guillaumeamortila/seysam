<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

include("app/view/layout/header.inc.php"); ?>

<?php notification("Informations personnelles modifiées.", "Erreur lors de la mofidifaction de vos informations personnelles."); ?>

<?php notificationForm("Tous les champs obligatoires doivent être renseignés."); ?>

    <div class="row">
        <div class="col-md-12 art">
            <h1>Modifier mes informations personnelles</h1>
        </div>
    </div>

    <div class="row flat-card">
        <div class="col-md-12">
            <form id="form_post" method="post" action="?module=user&action=update">
                <div class="form-group">
                    <label for="userPass">Mot de passe <span class="reqLgd">*</span></label>
                    <input id="userPass" type="password" class="form-control" name="user_pass">
                </div>
                <div class="form-group">
                    <label for="userEmail">Email <span class="reqLgd">*</span></label>
                    <input id="userEmail" type="text" class="form-control" value="<?php echo $user["user_mail"]; ?>" name="user_mail">
                </div>
                <div class="form-group">
                    <label for="userDisplayName">Nom affiché <span class="reqLgd">*</span></label>
                    <input id="userDisplayName" type="text" class="form-control" value="<?php echo $user["user_fname"]; ?>" name="user_fname">
                </div>
                <button type="submit" class="btn btn-primary">Modifier</button><p class="lgd">* champs obligatoires</p>
            </form>
        </div>
    </div>

<?php include("app/view/layout/footer.inc.php"); ?>