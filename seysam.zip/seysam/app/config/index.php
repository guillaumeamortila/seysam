<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");