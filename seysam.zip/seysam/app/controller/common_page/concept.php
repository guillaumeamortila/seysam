<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

// Definir le titre de la page
define("PAGE_TITLE", "Concept du site");
include_once("app/view/common_page/concept.php");