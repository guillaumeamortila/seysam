<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

// Definir le titre de la page
define("PAGE_TITLE", "Mentions légales de Seysam");
include_once("app/view/common_page/mentions.php");