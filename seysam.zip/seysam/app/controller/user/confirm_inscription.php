<?php

if(!defined("_BASE_URL")) die("Ressource interdite!");

define("PAGE_TITLE", "Confirmation inscription");
include_once("app/view/user/confirm_inscription.php");
