<?php

echo "la"; exit;